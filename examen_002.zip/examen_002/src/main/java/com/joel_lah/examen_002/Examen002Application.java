package com.joel_lah.examen_002;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Examen002Application {

	public static void main(String[] args) {
		SpringApplication.run(Examen002Application.class, args);
	}

}
