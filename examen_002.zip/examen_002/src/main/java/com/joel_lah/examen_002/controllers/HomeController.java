package com.joel_lah.examen_002.controllers;

import org.springframework.stereotype.Controller;

@Controller
public class HomeController {
    
}
