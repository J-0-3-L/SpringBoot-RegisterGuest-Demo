package com.joel_lah.examen_002;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Examen002ApplicationTests {

	@Test
	void contextLoads() {
	}

}
